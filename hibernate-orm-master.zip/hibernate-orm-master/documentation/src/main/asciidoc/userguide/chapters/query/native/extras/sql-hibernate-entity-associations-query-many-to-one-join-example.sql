SELECT
    *
FROM
    Phone ph
JOIN
    Person pr
ON  ph.person_id = pr.id
